from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))
bad=[p for p,h in m["files"].items() if not (r/p).is_file() or hashlib.sha256((r/p).read_bytes()).hexdigest()!=h]
if bad:raise SystemExit(str(bad))
assert not any(p.startswith("tb/") or p.endswith("/pt.tcl") or "qk_pv_mac" in p for p in m["files"])
assert "pt_shell" not in (r/"synopsys/run_flow.py").read_text(encoding="utf-8")
print("PASS 32PE tile allocation upload hashes:",len(m["files"]),"files; DC only; no QK/PV MAC")

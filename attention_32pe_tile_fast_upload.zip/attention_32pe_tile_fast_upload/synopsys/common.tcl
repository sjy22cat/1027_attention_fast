source $::env(TILE_PPA_CONFIG)
file mkdir $run_dir
set_app_var search_path [concat $search_path [list .] $db_search_dirs]
proc save_report {filename command} {
    global run_dir
    redirect -file [file join $run_dir $filename] {uplevel 1 $command}
}

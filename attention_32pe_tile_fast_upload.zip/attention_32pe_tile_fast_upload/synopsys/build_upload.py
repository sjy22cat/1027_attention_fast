from datetime import datetime
from pathlib import Path
import hashlib,json,shutil,tempfile,zipfile

ROOT=Path(__file__).resolve().parents[1]
NAME="attention_32pe_tile_fast_upload"
VERIFY='''from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))
bad=[p for p,h in m["files"].items() if not (r/p).is_file() or hashlib.sha256((r/p).read_bytes()).hexdigest()!=h]
if bad:raise SystemExit(str(bad))
assert not any(p.startswith("tb/") or p.endswith("/pt.tcl") or "qk_pv_mac" in p for p in m["files"])
assert "pt_shell" not in (r/"synopsys/run_flow.py").read_text(encoding="utf-8")
print("PASS 32PE tile allocation upload hashes:",len(m["files"]),"files; DC only; no QK/PV MAC")
'''


def main():
    names=["README.md","SOURCE_SNAPSHOT.json","sources.f"]
    names+=(ROOT/"sources.f").read_text(encoding="utf-8").splitlines()
    names += ["synopsys/"+p for p in ("site.example.json","result.template.json","common.tcl","constraints.tcl","dc.tcl",
        "dc_analysis.tcl","dc_reports.py","flow_helpers.py","run_flow.py","collect_candidate.py",
        "PROMPT_SYNOPSYS.md","build_upload.py")]
    output=ROOT/"upload";output.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="row-ppa-upload-") as td:
        folder=Path(td)/NAME;folder.mkdir()
        for p in names:
            target=folder/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,target)
        (folder/"verify_upload.py").write_text(VERIFY,encoding="utf-8")
        names += ["verify_upload.py","UPLOAD_FILE_LIST.txt"]
        (folder/"UPLOAD_FILE_LIST.txt").write_text("\n".join(sorted(names+["UPLOAD_MANIFEST.json"]))+"\n",encoding="utf-8")
        hashes={p:hashlib.sha256((folder/p).read_bytes()).hexdigest() for p in names}
        (folder/"UPLOAD_MANIFEST.json").write_text(json.dumps(dict(files=hashes),indent=2)+"\n",encoding="utf-8")
        archive=Path(td)/(NAME+".zip")
        with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED) as z:
            for p in sorted(names+["UPLOAD_MANIFEST.json"]):z.write(folder/p,NAME+"/"+p)
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            for p,h in hashes.items():assert hashlib.sha256(z.read(NAME+"/"+p)).hexdigest()==h
        previous=[output/NAME,output/(NAME+".zip"),output/"syn_32pe_tile_fast.md"]
        if any(p.exists() for p in previous):
            history=ROOT/"_history"/("upload_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
            assert history.resolve().is_relative_to(ROOT.resolve());history.mkdir(parents=True)
            for p in previous:
                assert p.resolve().parent==output.resolve()
                assert (history/p.name).resolve().is_relative_to(history.resolve())
                if p.exists():shutil.move(str(p),str(history/p.name))
        shutil.copytree(folder,output/NAME);shutil.copyfile(archive,output/(NAME+".zip"))
        shutil.copyfile(ROOT/"synopsys/PROMPT_SYNOPSYS.md",output/"syn_32pe_tile_fast.md")
    print(output/(NAME+".zip"));print("PASS ZIP/expanded hashes:",len(hashes),"files")


if __name__=="__main__":main()

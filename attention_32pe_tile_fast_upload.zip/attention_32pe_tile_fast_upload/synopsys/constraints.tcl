# All physical inputs below are in ns/pF, converted to actual tool units.
# Confirm report_units BEFORE accepting results.
set tu $tool_time_unit_ns
set cu $tool_capacitance_unit_pf
create_clock -name clk -period [expr {$period_ns/$tu}] [get_ports clk]
set_clock_uncertainty -setup [expr {0.050/$tu}] [get_clocks clk]
set_clock_uncertainty -hold [expr {0.020/$tu}] [get_clocks clk]
set_clock_transition [expr {0.050/$tu}] [get_clocks clk]
set dp [remove_from_collection [all_inputs] [get_ports {clk rst_n}]]
set_input_delay -max [expr {0.100/$tu}] -clock clk $dp
set_input_delay -min 0 -clock clk $dp
set_input_transition [expr {0.050/$tu}] $dp
set_output_delay -max [expr {0.100/$tu}] -clock clk [all_outputs]
set_output_delay -min 0 -clock clk [all_outputs]
set_load [expr {0.005/$cu}] [all_outputs]
set_max_transition [expr {0.200/$tu}] [current_design]
set_false_path -from [get_ports rst_n]
# External synchronous reset release is a system assumption. No FSM false paths,
# multicycle paths or fabricated input min delays may be added for timing closure.

"""Report per-32PE-tile local cost and x1024 array estimate; no latency scaling."""
import argparse,csv,json,math
from pathlib import Path
from flow_helpers import sha
from dc_reports import verify_dc_power_files


def attributes(path):
    if not path.is_file():return {}
    with path.open(encoding="utf-8") as stream:
        values={r["attribute"]:r["value_in_tool_units"] for r in csv.DictReader(stream,delimiter="\t")}
    result={}
    for key,text in values.items():
        try:value=float(text)
        except ValueError:continue
        if math.isfinite(value) and value>=0:result[key]=value
    return result


def collect(root):
    manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8"))
    model=json.loads((root/"schedule_model.json").read_text(encoding="utf-8"))
    identity=json.loads((root/"power_identity.json").read_text(encoding="utf-8"))
    if identity["netlist_sha256"]!=sha(root/"mapped.v") or identity["schedule_model"]!=model:
        raise ValueError("Power/model/netlist identity differs")
    verify_dc_power_files(root,identity)
    groups=manifest["groups"]
    if groups!=1 or manifest.get("dimension_tiles_per_head_group")!=4:
        raise ValueError("Expected one representative shared-four-tile group")
    area=attributes(root/"dc_area_raw.tsv").get("area")
    if area is not None:area*=manifest["site"]["library_area_unit_um2"]
    power=attributes(root/"power_raw.tsv")
    keys=("internal_power","switching_power","leakage_power")
    complete_power=all(key in power for key in keys)

    def scaled(factor):
        result=dict(area_um2=area*factor if area is not None else None,power_w=None,energy_estimate_pj=None)
        if complete_power:
            dynamic=(power["internal_power"]+power["switching_power"])*factor
            leakage=power["leakage_power"]*factor;duration=model["energy_estimation_duration_ns"]
            result["power_w"]=dict(dynamic=dynamic,leakage=leakage,total=dynamic+leakage)
            result["energy_estimate_pj"]=dict(dynamic=dynamic*duration*1000,
                leakage=leakage*duration*1000,total=(dynamic+leakage)*duration*1000,
                modeled_duration_ns=duration,basis="GENERIC_VECTORLESS_POWER_TIMES_FULL_HEAD_MODEL_WINDOW")
        return result

    per_tile=scaled(1/(4*groups))
    per_tile.update(status="AMORTIZED_SHARED_LOCAL_COST_NOT_INDEPENDENT_TILE_SYNTHESIS",
        pe_count=32,shared_group_tiles=4,
        basis="Divide the mapped group local cost equally across its four physical tiles; shared-head costs excluded")
    array=scaled(256)
    latency=dict(status="SCHEDULE_MODEL_NOT_REMEASURED",clock_model_ns=1.0,
        score_to_beta_nominal_ns=model["local_score_to_beta_nominal_ns"],
        score_to_local_state_min_nominal_ns=model["local_score_to_done_min_nominal_ns"],
        conditions=model["local_latency_conditions"],valid_ns=None,
        basis="Local shared-group schedule; no division by four or multiplication by 1024")
    per_tile["latency_model"]=latency
    array["latency_model"]=dict(latency)
    return dict(status="PARTIAL_TILE_LOCAL_ONLY_VECTORLESS_ESTIMATE",manifest=manifest,
        power_status=identity["power_status"],netlist_sha256=identity["netlist_sha256"],
        mapped_sample=scaled(1),one_32pe_tile_local_allocation=per_tile,
        physical_row_local_estimate=scaled(8/groups),
        single_head_16context_local_estimate=scaled(16/groups),
        full_array_1024tiles_local_estimate=array,
        factors=dict(sample_groups=groups,one_32pe_tile=1/(4*groups),
            one_physical_row=8/groups,one_head=16/groups,full_array=256/groups),
        full_head_schedule_model=model,
        array_scaling=dict(tile_count=1024,area_factor=1024,power_factor=1024,energy_factor=1024,
            latency_factor=1,basis="Simultaneous local operations; shared merge and data stalls excluded"),
        complete_tile_allocation_area_um2=None,
        complete_head_area_um2=None,complete_array_area_um2=None,complete_head_energy_pj=None,
        shared_costs_status="NOT_INCLUDED_NOT_ZERO",
        missing=["per-head cross-16row context reduction","running merge","query prescale",
                 "final inverse/output scale","head-level controller/state registers",
                 "cross-row broadcast/buffering/arbitration","physical MXFP4 PE and conversion","GSRAM/PHY/KV storage"],
        notes=["32 physical rows, not 1024. A physical row contains 32 tiles and 1024 PEs.",
               "Local group is shared by four dimension tiles; eight different head groups per physical row.",
               "One 32PE tile gets one-quarter of the shared group cost; multiplying this partial cost by 1024 gives array local cost only.",
               "Latency uses the global dependency schedule, never the area replication factor.",
               "Tail occupancy, gating and legal-command activity are uncharacterized; energy is an estimate."])


def main():
    ap=argparse.ArgumentParser(__doc__);ap.add_argument("results",type=Path);args=ap.parse_args()
    result=collect(args.results)
    path=args.results/"tile_nonmac.raw_candidate.json"
    path.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    summary=args.results/"RESULTS_SUMMARY.md"
    def fmt(value):return "PENDING" if value is None else f"{value:.9g}"
    lines=["# 32PE tile局部Attention非MAC估算", "",
        "仅含局部非MAC；每tile成本按四tile共享单元除4分摊。共享归约/最终归一化、物理PE、存储和互连未包含。", "",
        "| 范围 | 面积 µm² | 动态能量 pJ | 漏电能量 pJ | 总能量 pJ |", "|---|---:|---:|---:|---:|"]
    for label,key in (("1个32PE tile分摊","one_32pe_tile_local_allocation"),("1024 tile阵列局部合计","full_array_1024tiles_local_estimate")):
        values=result[key];energy=values["energy_estimate_pj"] or {}
        lines.append("| "+label+" | "+" | ".join(fmt(v) for v in
            (values["area_um2"],energy.get("dynamic"),energy.get("leakage"),energy.get("total")))+" |")
    lines += ["", "延迟按1ns/周期模型：已完成128维QK归约的score接受后，7ns产生beta；PV立即启动且及时返回时，13ns产生局部(m,l,z)状态。",
        "1024 tile并行时仍为同一局部延迟，不乘1024；全局context/running合并另计。不是STA闭合延迟。",
        "", f"能量为显式vectorless功率×{result['full_head_schedule_model']['energy_estimation_duration_ns']:g}ns模型窗口；不是活动实测。",
        "DC实际时序状态见dc_qor/setup/hold/constraints报告。功耗状态："+result["power_status"]["status"],
        "完整head非MAC沿用79ns（N1152）的既有调度模型，本包未测其共享硬件。"]
    summary.write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(path,"; shared-head costs NOT included; partial estimate only")
    print(summary)


if __name__=="__main__":main()

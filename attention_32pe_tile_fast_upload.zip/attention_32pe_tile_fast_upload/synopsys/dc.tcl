source synopsys/common.tcl
set_app_var target_library $target_db
set_app_var synthetic_library [list dw_foundation.sldb]
set_app_var link_library [concat [list *] $target_db $extra_link_db [list dw_foundation.sldb]]
if {$::env(DC_REUSE_MAPPED)=="1"} {
    read_verilog [file join $run_dir mapped.v]
    current_design attention_32pe_tile_local_nonmac_eval
    link
    source synopsys/constraints.tcl
} else {
    define_design_lib WORK -path [file join $run_dir work]
    # Only the local non-MAC sample; do not analyze/elaborate any MAC or head top.
    analyze -format sverilog [list rtl/attention_softmax_external_mac_lane.sv rtl/attention_32pe_tile_local_nonmac_eval.sv]
    elaborate attention_32pe_tile_local_nonmac_eval
    current_design attention_32pe_tile_local_nonmac_eval
    link
    source synopsys/constraints.tcl
    save_report dc_check_before.rpt {check_design}
    compile -map_effort medium
    write -format verilog -hierarchy -output [file join $run_dir mapped.v]
    write_sdc [file join $run_dir mapped.sdc]
}
source synopsys/dc_analysis.tcl
exit

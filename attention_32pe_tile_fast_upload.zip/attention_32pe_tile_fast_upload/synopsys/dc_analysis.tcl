# Lightweight mapped STA, area and vectorless power, all inside dc_shell.
# No PrimeTime commands or independent timing/power process is needed.
save_report dc_units.rpt {report_units}
save_report dc_check_after.rpt {check_design}
save_report dc_qor.rpt {report_qor}
save_report dc_setup.rpt {report_timing -delay_type max -max_paths 10 -nets -transition_time -capacitance -input_pins}
save_report dc_hold.rpt {report_timing -delay_type min -max_paths 10 -nets -transition_time -capacitance -input_pins}
save_report dc_constraints.rpt {report_constraint}
save_report dc_area.rpt {report_area -hierarchy}
save_report dc_resources.rpt {report_resources -hierarchy}
save_report dc_references.rpt {report_reference -hierarchy}
set af [open [file join $run_dir dc_area_raw.tsv] w]
puts $af "attribute\tvalue_in_tool_units"
if {[catch {get_attribute -quiet [current_design] area} area] || $area==""} {set area UNAVAILABLE}
puts $af "area\t$area"
close $af

# Power Compiler commands/licensing vary by installation. Redirect failures so
# optional power unavailability cannot discard the completed mapping/STA/area.
# Confirm -period syntax with this DC version's help/man. The value below is
# the number of transitions in one clock period, not transitions per ns.
set pf [open [file join $run_dir dc_power_status.txt] w]
if {[catch {
    redirect -file [file join $run_dir dc_power_attempt.rpt] {
        set data_inputs [remove_from_collection [all_inputs] [get_ports {clk rst_n}]]
        set activity_period [expr {$period_ns/$tool_time_unit_ns}]
        set_switching_activity -static_probability $vectorless_static_probability \
            -toggle_rate $vectorless_toggle_rate_per_cycle -period $activity_period $data_inputs
        set_switching_activity -static_probability 0.5 -toggle_rate 2.0 \
            -period $activity_period [get_ports clk]
        set_switching_activity -static_probability 1.0 -toggle_rate 0.0 [get_ports rst_n]
        save_report power_total.rpt {report_power}
    }
} power_reason]} {
    puts $pf "PENDING"
    puts $pf $power_reason
    puts "Warning: DC power estimate unavailable; retain mapped area and timing. See dc_power_attempt.rpt."
} else {
    puts $pf "REPORT_AVAILABLE"
    puts $pf "DC/Power Compiler vectorless report; units must be verified"
    # Optional diagnostic command; not every DC release provides it.
    catch {save_report power_activity.rpt {report_switching_activity}}
}
close $pf
set af [open [file join $run_dir power_assumptions.txt] w]
puts $af "DC_POWER_COMPILER; VECTORLESS_ASSUMED_ACTIVITY; no functional simulation or command trace"
puts $af "Data/control inputs: $vectorless_toggle_rate_per_cycle transitions per clock period; P(1)=$vectorless_static_probability"
puts $af "Clock: 2 transitions per period; rst_n: constant 1; FSM/length correlations uncharacterized"
close $af

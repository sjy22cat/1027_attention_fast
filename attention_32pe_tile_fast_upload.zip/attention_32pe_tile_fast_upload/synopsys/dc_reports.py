"""Normalize unit-labelled DC power totals; never guess DC attribute units."""
import csv, hashlib, json, math, re

TOOL = "DC_POWER_COMPILER"
SCALES = {"w": 1.0, "mw": 1e-3, "uw": 1e-6, "nw": 1e-9,
          "pw": 1e-12, "fw": 1e-15}
LABELS = {"Cell Internal Power": "internal_power",
          "Net Switching Power": "switching_power",
          "Cell Leakage Power": "leakage_power",
          "Total Dynamic Power": "dynamic_power", "Total Power": "total_power"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clear_power_outputs(out):
    # Fixed analysis outputs only; the mapped netlist is retained for reuse.
    for name in ("power_raw.tsv", "power_status.json", "power_identity.json",
                 "power_total.rpt", "power_activity.rpt", "power_assumptions.txt",
                 "dc_power_attempt.rpt", "dc_power_status.txt"):
        (out / name).unlink(missing_ok=True)


def parse_power_report(data):
    values = {}
    normalized = data.replace("µ", "u").replace("μ", "u")
    for label, attr in LABELS.items():
        match = re.search(r"(?mi)^\s*" + re.escape(label) +
                          r"\s*=\s*([+\-\d.eE]+)\s*([munpf]?W)\b", normalized)
        if match:
            value = float(match[1]) * SCALES[match[2].lower()]
            if not math.isfinite(value) or value < 0:
                raise ValueError("Invalid power: " + label)
            values[attr] = value
    required = ("internal_power", "switching_power", "leakage_power")
    if any(k not in values for k in required):
        raise ValueError("Missing explicitly unit-labelled internal/switching/leakage totals; review report_power manually")
    dynamic = values["internal_power"] + values["switching_power"]
    total = dynamic + values["leakage_power"]
    for key, expected in (("dynamic_power", dynamic), ("total_power", total)):
        if key in values and not math.isclose(values[key], expected, rel_tol=0.005, abs_tol=1e-15):
            raise ValueError("Inconsistent DC power totals: " + key)
    values.update(dynamic_power=dynamic, total_power=total)
    return values


def finalize_power(out, model_key, model, assumptions):
    status = dict(status="PENDING", analysis_tool=TOOL,
                  reason="No complete DC power report")
    report = out / "power_total.rpt"
    tool_status = out / "dc_power_status.txt"
    text = tool_status.read_text(encoding="utf-8", errors="replace") if tool_status.is_file() else ""
    if text.startswith("REPORT_AVAILABLE") and report.is_file():
        try:
            report_text = report.read_text(encoding="utf-8", errors="replace")
            # Some Synopsys commands print errors but do not raise a Tcl error.
            attempt = out / "dc_power_attempt.rpt"
            attempt_text = attempt.read_text(encoding="utf-8", errors="replace") if attempt.is_file() else ""
            if re.search(r"(?m)^\s*(?:Error:|FATAL:|Fatal:)", report_text + "\n" + attempt_text):
                raise ValueError("DC power command reported errors; see dc_power_attempt.rpt/power_total.rpt")
            values = parse_power_report(report_text)
            with (out / "power_raw.tsv").open("w", encoding="utf-8", newline="") as stream:
                writer = csv.writer(stream, delimiter="\t")
                writer.writerow(("attribute", "value_in_tool_units"))
                writer.writerows(values.items())
            status.update(status="ESTIMATED", reason="Unit-labelled DC totals normalized to W")
        except ValueError as exc:
            status["reason"] = str(exc)
    elif text:
        status["reason"] = text.strip()
    identity = dict(netlist_sha256=sha(out / "mapped.v"), assumptions=assumptions,
                    analysis_tool=TOOL, power_unit_w=1.0, power_status=status,
                    **{model_key: model})
    if report.is_file():
        identity["power_report_sha256"] = sha(report)
    if (out / "power_raw.tsv").is_file():
        identity["power_raw_sha256"] = sha(out / "power_raw.tsv")
    for name, value in (("power_status.json", status), ("power_identity.json", identity)):
        (out / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    return status


def verify_dc_power_files(out, identity):
    if identity.get("analysis_tool") != TOOL:
        return  # Historical PT records keep their original explicit provenance.
    for filename, key in (("power_total.rpt", "power_report_sha256"),
                          ("power_raw.tsv", "power_raw_sha256")):
        path = out / filename
        if (path.is_file() or key in identity) and (not path.is_file() or identity.get(key) != sha(path)):
            raise ValueError("Power report/raw identity differs: " + filename)

#!/usr/bin/env python3
"""One local non-MAC shared sample, allocated per 32PE tile; DC only."""
import argparse,json,math,os
from pathlib import Path
from flow_helpers import execute,write_config,sha
from dc_reports import clear_power_outputs,finalize_power

ROOT=Path(__file__).resolve().parents[1]


def schedule(n=1152):
    waves=(n+511)//512
    return dict(n=n,waves=waves,clock_model_ns=1.0,
        full_head_command_cycles=39*waves+4,external_mac_cycles=14*waves,
        full_head_nonmac_schedule_cycles=25*waves+4,
        local_max_diff_exp_cycles_per_wave=7,
        local_denominator_cycles_per_wave=6,
        local_score_to_beta_nominal_ns=7.0,
        local_score_to_done_min_nominal_ns=13.0,
        local_latency_conditions="From accepted scores; immediate PV launch and timely reply; no extra stalls",
        denominator_overlaps_external_pv=True,
        local_arithmetic_cycles_all_waves=13*waves,
        shared_and_controller_cost_included=False,
        energy_estimation_duration_ns=float(39*waves+4),
        valid_ns=None,basis="Existing schedule; 1ns/cycle; no new simulation")


def main():
    ap=argparse.ArgumentParser(__doc__)
    ap.add_argument("--site",default="synopsys/site.json")
    ap.add_argument("--stage",choices=("all","analyze"),default="all")
    ap.add_argument("--n",type=int,default=1152)
    ap.add_argument("--output",default="results/smic28_32pe_tile")
    args=ap.parse_args();os.chdir(ROOT)
    if not 1<=args.n<=1152:raise ValueError("N outside [1,1152]")
    site=json.loads(Path(args.site).read_text(encoding="utf-8"))
    site.setdefault("vectorless_toggle_rate_per_cycle",0.1)
    site.setdefault("vectorless_static_probability",0.5)
    for key in ("period_ns","tool_time_unit_ns","tool_capacitance_unit_pf","library_area_unit_um2"):
        value=site[key]
        if type(value) not in (int,float) or not math.isfinite(value) or value<=0:
            raise ValueError("Invalid unit/period: "+key)
    if site["period_ns"]!=1.0:raise ValueError("This estimate uses the requested fixed 1ns period")
    toggle=site["vectorless_toggle_rate_per_cycle"];prob=site["vectorless_static_probability"]
    if type(toggle) not in (int,float) or not math.isfinite(toggle) or toggle<0:raise ValueError("Invalid toggle rate")
    if type(prob) not in (int,float) or not math.isfinite(prob) or not 0<=prob<=1:raise ValueError("Invalid probability")
    for path in site["target_db"]+site["extra_link_db"]:
        if not Path(path).is_file():raise FileNotFoundError(path)
    out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True)
    sources=(ROOT/"sources.f").read_text(encoding="utf-8").splitlines()
    manifest=dict(scope="one_32pe_tile_allocated_local_nonmac_only",groups=1,
        top="attention_32pe_tile_local_nonmac_eval",
        physical_tiles_per_row=32,pe_per_tile=32,physical_rows=32,
        context_rows_per_head=16,dimension_tiles_per_head_group=4,
        groups_per_row=8,head_units=16,n=args.n,site=site,
        source_sha256={p:sha(ROOT/p) for p in sources},
        power_mode="VECTORLESS_ASSUMED_ACTIVITY",functional_simulation="SKIPPED_PER_USER_REQUEST")
    path=out/"manifest.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8"))!=manifest:
        raise ValueError("Changed inputs; choose another --output")
    path.write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
    model=schedule(args.n)
    (out/"schedule_model.json").write_text(json.dumps(model,indent=2)+"\n",encoding="utf-8")
    reuse=args.stage=="analyze"
    if reuse and not (out/"mapped.v").is_file():raise RuntimeError("No existing mapped.v")
    config=write_config(site,out)
    env=dict(os.environ,TILE_PPA_CONFIG=str(config),DC_REUSE_MAPPED="1" if reuse else "0")
    clear_power_outputs(out)
    execute(["dc_shell","-f","synopsys/dc.tcl"],out/("dc_analyze.log" if reuse else "dc.log"),env)
    if not (out/"mapped.v").is_file():raise RuntimeError("Mapping did not produce mapped.v")
    assumptions=dict(mode="VECTORLESS_ASSUMED_ACTIVITY",toggle_rate_per_cycle=toggle,
        static_probability=prob,clock_toggles_per_cycle=2.0,reset_n_static_probability=1.0,
        state_correlation="Uncharacterized; identical generic assumption for active and tail-masked lanes")
    status=finalize_power(out,"schedule_model",model,assumptions)
    print("DC-only 32PE tile cost sample:",out,"; power",status["status"],status["reason"])


if __name__=="__main__":main()

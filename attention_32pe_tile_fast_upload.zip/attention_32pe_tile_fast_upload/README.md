# 32个PE（1个tile）的局部Attention非MAC综合包

本包以**1个tile=32个PE**为最小计价单位，估算1024个tile阵列的局部非MAC成本。只综合小样本，不再综合原16ctx×4dim完整FP32 Attention，不实例化QK/PV MAC、物理PE或K/V bank。源代码只含两个RTL文件。

## 测量电路与每tile分摊

现有映射中，一个128维head的32-token context分块由4个维度tile共同处理。4个tile先完成128维QK归约，再共享一套32-score局部softmax；每个tile不能对各自的32维部分QK结果独立做softmax。

综合顶层`attention_32pe_tile_local_nonmac_eval`保留这一完整共享单元：32个exp、32个浮点减法、31个分母加法、比较树、必要寄存器和外部PV握手。它接收完整score，输出未归一化beta，接收外部PV的128维加权结果，产生局部`(present,m,l,z)`。QK/PV通过真实外部接口提供，不包含黑盒MAC或用于PPA的行为MAC。

**综合的是完整共享单元；每tile数字是其1/4成本分摊，不是独立tile完整Attention实测。** 不将HEAD_DIM降到32，不将softmax算子拆成四分之一后冒充完整算法。原系统32个物理PE的成本不在此包中，沿用原系统MAC数据时不得再加一份FP32 MAC。

设样本面积/能量为A、E：

| 范围 | 面积 | 相同模型窗口下的估计能量 |
|---|---:|---:|
| 1个32PE tile局部分摊 | A/4 | E/4 |
| 1024个tile的局部非MAC合计 | 1024×A/4=256A | 1024×E/4=256E |

一个物理row包含32个tile，全阵列有32个row。每head使用16ctx×4dim=64个tile，整个阵列对应16个head。跨16个context row的统计归约、running merge、query预缩放、最终倒数/输出缩放、head级控制和全局互连是共享项S，本包不测它们。完整新增非MAC面积约`256A+16S`，每tile完整分摊约`A/4+S/64`。本轮先输出局部结果，共享部分保留缺失，不默认零；局部结果不能冒充完整PE阵列面积或完整Attention总能耗。

## 延迟计算

按用户指定1ns/周期建模，无新功能仿真：

| 局部阶段 | 周期/名义ns |
|---|---:|
| 接受完整score后，5级最大值树 | 5 |
| 并行score减最大值 | 1 |
| 并行exp，beta有效 | 1 |
| PV请求接受，同时装载分母求和树叶子 | 1 |
| 5级分母加法树，与外部PV重叠 | 5 |
| score接受到beta | 7 |
| score接受到局部(m,l,z)状态有效 | 最少13 |

13ns要求PV立即启动且及时返回，无额外停顿；不包括QK形成score的时间。PV更慢、接口背压或存储等待会延长局部状态完成时间。

**1024 tile并行时，局部延迟仍为7/13ns，不乘1024，也不除4。** 延迟由依赖链决定。跨context归约、running merge和最终归一化另计。既有N=1152完整head模型仍为121拍总命令、42拍外部QK/PV、79拍非MAC调度余项；79ns并非本小样本测得的延迟，不能再与13ns重复叠加。

DC的实际setup/hold/电气状态单独报告。即使未满足1ns，仍按上述周期建模，不把模型值声称为时序闭合延迟。

## 能耗与单位

采用DC/Power Compiler的vectorless假设：非clk/reset输入0.1次翻转/周期、P(1)=0.5，clk每周期2次翻转，rst_n恒1。动态/漏电单位分别核对并统一为W。能量按`E_pJ=P_W×121ns×1000`估算默认N=1152的一次完整head模型窗口，包含本模块在外部MAC/共享merge等待期间的模型时钟和漏电成本；不包含外部模块自身功耗。

尾wave利用率、门控、合法FSM阶段和命令活动未表征。因此能量是明确假设下的估计，不能当作真实活动能耗。样本缺功耗许可或无法解析报告时，能耗保持null/PENDING，面积和时序结果仍交付。

## 上传与执行

只上传`upload/attention_32pe_tile_fast_upload.zip`，解压后进入同名目录，把`upload/syn_32pe_tile_fast.md`给服务器Codex。填写SMIC库路径后：

```bash
python3 verify_upload.py
cp synopsys/site.example.json synopsys/site.json
# 填SMIC .db路径，核对单位
python3 synopsys/run_flow.py
python3 synopsys/collect_candidate.py results/smic28_32pe_tile
```

仅一次DC中等强度映射，完成DC基本STA、面积及Power Compiler估计功耗。无PT/VCS、功能仿真、种子/N扫描、Fmax搜索、重复闭合或全局DDC。若有相同源码/库/约束的映射结果，用`--stage analyze --output <已有结果目录>`复用，不重新compile。

输出`tile_nonmac.raw_candidate.json`和`RESULTS_SUMMARY.md`，包括样本、每32PE tile分摊、1024tile局部总量，以及局部延迟模型。面积µm²、能量pJ；完整head/阵列总值因缺共享成本而保持null。源码快照见`SOURCE_SNAPSHOT.json`；原上传包、SIM-1023、Excel及物理PE RTL不改。

本地只做脚本测试、打包校验及允许缺失授权DW模块的RTL静态展开检查，不运行RTL功能仿真，也未在本地执行新思综合。

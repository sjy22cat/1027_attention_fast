`timescale 1ns/1ps
// Local non-MAC state for one context tile. QK scores and beta*V arrive
// through real external interfaces; no QK/PV arithmetic or K/V bank exists.
module attention_softmax_external_mac_lane #(
    parameter integer TILE_SIZE=32, HEAD_DIM=128
)(
    input wire clk,rst_n,i_start,
    input wire [TILE_SIZE-1:0] i_mask,
    input wire i_score_valid,
    output wire o_score_ready,
    input wire [TILE_SIZE*32-1:0] i_score,
    output wire o_pv_request,
    input wire i_pv_launch,
    output wire [TILE_SIZE*32-1:0] o_beta,
    input wire i_pv_valid,
    output wire o_pv_ready,
    input wire [HEAD_DIM*32-1:0] i_pv_z,
    output wire o_done,o_present,o_qk_wait,o_pv_wait,
    output wire [31:0] o_m,o_l,
    output wire [HEAD_DIM*32-1:0] o_z
);
    localparam integer LEVELS=$clog2(TILE_SIZE);
    localparam integer IDLE=0,QK_WAIT=1,MAXIMUM=2,DIFFERENCE=3,
        EXPONENT=4,PV_REQUEST=5,PV_REDUCE=6,PV_WAIT=7,DONE=8;
    reg [3:0] state;
    integer level_q;
    reg [TILE_SIZE-1:0] mask_q;
    reg pv_received_q;
    reg [HEAD_DIM*32-1:0] pv_z_q;
    reg [31:0] score_q[0:TILE_SIZE-1],diff_q[0:TILE_SIZE-1],beta_q[0:TILE_SIZE-1];
    reg [31:0] max_q[1:TILE_SIZE-1],sum_q[1:2*TILE_SIZE-1];
    wire [31:0] maximum[1:2*TILE_SIZE-1],difference[0:TILE_SIZE-1];
    wire [31:0] exponent[0:TILE_SIZE-1],addition[1:TILE_SIZE-1];
    function automatic [31:0] fp_max(input [31:0] a,b);
        if(a[31]!=b[31]) fp_max=a[31]?b:a;
        else if(a[31]) fp_max=(a[30:0]<b[30:0])?a:b;
        else fp_max=(a[30:0]>b[30:0])?a:b;
    endfunction
    initial if(TILE_SIZE<2 || TILE_SIZE>32 || (TILE_SIZE&(TILE_SIZE-1))!=0)
        $fatal(1,"TILE_SIZE must be a power of two in [2,32]");
    assign o_score_ready=state==QK_WAIT;
    assign o_pv_request=state==PV_REQUEST;
    assign o_pv_ready=(state==PV_REDUCE || state==PV_WAIT) && !pv_received_q;
    assign o_done=state==DONE;
    assign o_present=|mask_q;
    assign o_m=o_present?max_q[1]:32'b0;
    assign o_l=o_present?sum_q[1]:32'b0;
    assign o_z=o_present?pv_z_q:{HEAD_DIM*32{1'b0}};
    assign o_qk_wait=state==QK_WAIT;
    // Count external PV occupancy only until its reply. If PV is faster than
    // the denominator tree, the remaining sum cycles belong to non-MAC time.
    assign o_pv_wait=state==PV_REQUEST ||
        ((state==PV_REDUCE || state==PV_WAIT) && !pv_received_q);
    genvar p,n;
    generate
        for(p=0;p<TILE_SIZE;p=p+1) begin:g_score
            wire [7:0] sd,se;
            assign maximum[TILE_SIZE+p]=mask_q[p]?score_q[p]:32'hff800000;
            assign o_beta[p*32+:32]=(state>=PV_REQUEST && mask_q[p])?beta_q[p]:32'b0;
            DW_fp_addsub #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_diff(
                .a(mask_q[p]?score_q[p]:32'b0),.b(o_present?max_q[1]:32'b0),
                .rnd(3'b000),.op(1'b1),.z(difference[p]),.status(sd));
            DW_fp_exp #(.sig_width(23),.exp_width(8),.ieee_compliance(0),.arch(2)) u_exp(
                .a(diff_q[p]),.z(exponent[p]),.status(se));
        end
        for(n=1;n<TILE_SIZE;n=n+1) begin:g_tree
            if(n>=TILE_SIZE/2) begin:g_bottom
                assign maximum[n]=fp_max(maximum[2*n],maximum[2*n+1]);
            end else begin:g_upper
                assign maximum[n]=fp_max(max_q[2*n],max_q[2*n+1]);
            end
            wire [7:0] status;
            DW_fp_addsub #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_sum(
                .a(sum_q[2*n]),.b(sum_q[2*n+1]),.rnd(3'b000),.op(1'b0),
                .z(addition[n]),.status(status));
        end
    endgenerate
    integer ip,inode;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;level_q<=0;mask_q<=0;pv_received_q<=0;end
        else begin
            if(i_pv_valid && o_pv_ready) begin pv_z_q<=i_pv_z;pv_received_q<=1;end
            case(state)
                IDLE:if(i_start) begin mask_q<=i_mask;pv_received_q<=0;state<=QK_WAIT;end
                QK_WAIT:if(i_score_valid) begin
                    for(ip=0;ip<TILE_SIZE;ip=ip+1) score_q[ip]<=mask_q[ip]?i_score[ip*32+:32]:32'b0;
                    level_q<=1;state<=MAXIMUM;
                end
                MAXIMUM:begin
                    for(inode=1;inode<TILE_SIZE;inode=inode+1)
                        if(inode>=(TILE_SIZE>>level_q) && inode<(TILE_SIZE>>(level_q-1)))
                            max_q[inode]<=maximum[inode];
                    if(level_q==LEVELS) state<=DIFFERENCE;else level_q<=level_q+1;
                end
                DIFFERENCE:begin
                    for(ip=0;ip<TILE_SIZE;ip=ip+1) diff_q[ip]<=mask_q[ip]?difference[ip]:32'b0;
                    state<=EXPONENT;
                end
                EXPONENT:begin
                    for(ip=0;ip<TILE_SIZE;ip=ip+1) beta_q[ip]<=mask_q[ip]?exponent[ip]:32'b0;
                    state<=PV_REQUEST;
                end
                PV_REQUEST:if(i_pv_launch) begin
                    for(ip=0;ip<TILE_SIZE;ip=ip+1) sum_q[TILE_SIZE+ip]<=beta_q[ip];
                    level_q<=1;state<=PV_REDUCE;
                end
                PV_REDUCE:begin
                    for(inode=1;inode<TILE_SIZE;inode=inode+1)
                        if(inode>=(TILE_SIZE>>level_q) && inode<(TILE_SIZE>>(level_q-1)))
                            sum_q[inode]<=addition[inode];
                    if(level_q==LEVELS)
                        state<=(pv_received_q || (i_pv_valid && o_pv_ready))?DONE:PV_WAIT;
                    else level_q<=level_q+1;
                end
                PV_WAIT:if(pv_received_q || (i_pv_valid && o_pv_ready)) state<=DONE;
                DONE:state<=IDLE;
                default:state<=IDLE;
            endcase
        end
    end
endmodule

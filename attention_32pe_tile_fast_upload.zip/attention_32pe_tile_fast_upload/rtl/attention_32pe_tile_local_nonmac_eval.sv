`timescale 1ns/1ps
// Representative LOCAL non-MAC hardware for per-32PE-tile cost allocation.
// One physical tile has 32 PEs. Four dimension tiles jointly finish a 128-D
// QK dot product and share this complete 32-score Softmax/PV-state interface.
// Synthesize this one shared instance; allocate area/power/energy / 4 to each
// physical tile. This is not an independent 32-D Attention head or a PE array.
// QK/PV arithmetic, K/V banks and cross-context/global merge are external.
module attention_32pe_tile_local_nonmac_eval (
    input wire clk,rst_n,i_start,
    input wire [31:0] i_token_mask,
    input wire i_score_valid,
    output wire o_score_ready,
    input wire [32*32-1:0] i_score,
    output wire o_pv_request,
    input wire i_pv_launch,
    output wire [32*32-1:0] o_beta,
    input wire i_pv_valid,
    output wire o_pv_ready,
    input wire [128*32-1:0] i_pv_z,
    output wire o_done,o_present,o_qk_wait,o_pv_wait,
    output wire [31:0] o_m,o_l,
    output wire [128*32-1:0] o_z
);
    attention_softmax_external_mac_lane #(.TILE_SIZE(32),.HEAD_DIM(128)) u_local (
        .clk(clk),.rst_n(rst_n),.i_start(i_start),.i_mask(i_token_mask),
        .i_score_valid(i_score_valid),.o_score_ready(o_score_ready),.i_score(i_score),
        .o_pv_request(o_pv_request),.i_pv_launch(i_pv_launch),.o_beta(o_beta),
        .i_pv_valid(i_pv_valid),.o_pv_ready(o_pv_ready),.i_pv_z(i_pv_z),
        .o_done(o_done),.o_present(o_present),.o_qk_wait(o_qk_wait),.o_pv_wait(o_pv_wait),
        .o_m(o_m),.o_l(o_l),.o_z(o_z));
endmodule
